-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : ot
-- 
-- Part : #1
-- Date : 2016-07-12 17:05:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ot_ credential`
-- -----------------------------
DROP TABLE IF EXISTS `ot_ credential`;
CREATE TABLE `ot_ credential` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '证书id',
  `cert_no` varchar(255) NOT NULL COMMENT '证书编号',
  `create_admin` varchar(255) NOT NULL COMMENT '创建人',
  `create_time` int(11) NOT NULL COMMENT '生成时间',
  `v_period` int(11) NOT NULL COMMENT '有效期',
  `Begin_time` int(11) NOT NULL COMMENT '开始日期',
  `End_time` int(11) NOT NULL COMMENT '结束日期',
  `Cert_adminc` varchar(255) NOT NULL COMMENT '证书持有人',
  `Query_logs` int(11) NOT NULL COMMENT '查询次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

